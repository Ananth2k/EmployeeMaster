<?php
namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table      = 'list';
    protected $primaryKey = 'EMPLOYEE_ID';
    protected $useAutoIncrement = true;
    protected $allowedFields = [

            'EMPLOYEE_ID', 
            'EMPLOYEE_NAME',
            'ADDRESS',
            'SALARY',
            'DOB'       
    ];
}