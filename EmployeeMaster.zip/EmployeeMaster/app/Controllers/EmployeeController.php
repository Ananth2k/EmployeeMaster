<?php

namespace App\Controllers;
use \App\Models\EmployeeModel;

class EmployeeController extends BaseController
{
    public function index()
    {
    	$model = new EmployeeModel;
    	$data['employees'] = $model->orderby('EMPLOYEE_ID','ASC')->findAll();
    	echo view('partials/header');
        echo view('list.php',$data);
        echo view('partials/footer');
        
    }
    
      public function delete($ID = null)
    {
        $model = new EmployeeModel;
        $delete = $model->delete($ID);

        if ($delete) {
            session()->setFlashdata('success', 'Page deleted successfully.');
        } else {
            session()->setFlashdata('danger', 'Failed to delete Page .');
        }

        return redirect()->to(site_url('/'));
    }


    public function view($ID = null){

    
        $model = new EmployeeModel();
        $data['employees'] = $model->find($ID);
       	echo view('partials/header');
        echo view('view.php',$data);
        echo view('partials/footer');

        return;
        
        
    
}

  public function edit($ID = null){

    
        $model = new EmployeeModel();
        $data['employees'] = $model->find($ID);
       	echo view('partials/header');
        echo view('edit.php',$data);
        echo view('partials/footer');

        return;
        
        
    
}

public function update($ID)
{
    $model = new EmployeeModel();
    $employee = $model->find($ID);
    $data = [
        'EMPLOYEE_NAME' => $this->request->getVar('EMPLOYEE_NAME'),
        'SALARY' => $this->request->getVar('SALARY'),
        'ADDRESS' => $this->request->getVar('ADDRESS'),
        'DOB' => $this->request->getVar('DOB'),

    ];

    
    $model->update($ID, $data);
    

    return redirect()->to(site_url('/'));
}



public function add()
    {
        $validation = \Config\Services::validation();
        $model = new EmployeeModel;
        
        echo view('partials/header');
        echo view('add.php');
        echo view('partials/footer');
    }


    public function store()
    {
        $model = new EmployeeModel();
        $data = [
            'EMPLOYEE_NAME' => $this->request->getVar('EMPLOYEE_NAME'),
            'SALARY' => $this->request->getVar('SALARY'),
            'ADDRESS' => $this->request->getVar('ADDRESS'),
            'DOB' => $this->request->getVar('DOB'),

        ];
        $save = $model->insert($data);
        return redirect()->to(site_url('/'));

    }


}


    