<div class="wrapper">
	





	<div class="title_index">
			<h1 style="color:#007089">Employees List</h1>
			
		</div>
		<div class="title_index">
				<div class="col-6">
			<form class="d-flex">
			<input id="myInput" onkeyup="myFunction()" class="form-control me-2" type="search" placeholder="Search By Name . . ." aria-label="Search">
			<!-- <button class="btn btn-outline-primary" type="submit">Back</button> -->
			</form>
			
				</div>
				</div>
			



		<div class="table_space">


			<table id="myTable" class="table table-striped table-bordered">
				<thead class="table-info">
					<tr class="text-center-heading">
						<!-- <th class="text-center"scope="col ">No</th> -->
						<th class="text-center"scope="col ">Employee Id</th>
						<th class="text-center"scope="col ">Employee Name</th>
						<th class="text-center"scope="col ">Date of birth</th>
						<th class="text-center"scope="col ">Address</th>
						<th class="text-center"scope="col ">Salary</th>
						<th class="text-center"scope="col ">Action</th>
						<th class="text-center"scope="col ">View</th>

					</tr>
				</thead>
				<tbody>

					
					 	<?php if ($employees): 
					 		$n = 1;?>
           					
            			<?php foreach ($employees as $employee): ?>
						<tr class="text-center-row">
							<!-- <th class="text-center" scope="row"><?php echo $n++; ?></th> -->
							<th class="text-center" scope="row"><?php echo $employee['EMPLOYEE_ID']; ?></th>
							<td class="text-center"><?php echo $employee['EMPLOYEE_NAME']; ?></td>
							<td class="text-center"><?php echo $employee['DOB']; ?></td>
							<td class="text-center"><?php echo $employee['ADDRESS']; ?></td>
							<td class="text-center"><?php echo $employee['SALARY']; ?></td>
							
							

							<td class="text-center">


								

								<button  type="button" class="btn btn-danger " data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $employee['EMPLOYEE_ID'];?>">Delete</button>
								<a href="<?= base_url('/edit/'. $employee['EMPLOYEE_ID']) ?>"><button class="btn btn-warning ">Edit</button></a>





							</td>
							<td class="text-center">
								<a href="<?= base_url('/view/'. $employee['EMPLOYEE_ID']) ?>">
									<button type="submit"class="btn btn-primary">View</button></a>
								</td>

							</tr>
							<div  class="modal fade" id="exampleModal<?php echo $employee['EMPLOYEE_ID'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class="modal-header  bg-success">
											<h5 class="modal-title" id="exampleModalLabel">Delete</h5>
											<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<div class="formcontroll">
												<label>Confirm to Delete <span class="page_name"><?php echo $employee['EMPLOYEE_NAME']; ?></span> ?</label>
											</div>
										</div>
										<div class="card-footer">
										<a href="<?= base_url('/delete/'. $employee['EMPLOYEE_ID']) ?>">
										<button type="submit" class="btn btn-primary">Yes</button>
										</a>
										<button type="button"   class="btn btn-danger" data-bs-dismiss="modal">
										<span aria-hidden="true">No</span>
										</button>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
          					<?php endif; ?>
							

						
		
          				

					</tbody>
				</table>
			</div>
</div>